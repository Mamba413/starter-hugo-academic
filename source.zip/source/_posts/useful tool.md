---
title: Useful Tool
date: 2018-11-06 19:48:40
categories: Miscellaneous
tags: free software
---

I find several open-souce and free software which are useful for Window User:


| Software   | Function                        | Website                         |
| ---------- | ------------------------------- | ------------------------------- |
| OBS Studio | Make a video                    | https://obsproject.com/download |
| GIMP       | Image Processing like PhotoShop | https://www.gimp.org/           |
